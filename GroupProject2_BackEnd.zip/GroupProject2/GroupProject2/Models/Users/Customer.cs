﻿using GroupProject2.Models.Repairs;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Users
{
    public class Customer
    {

        [Key]
        public int Customer_ID { get; set; }
        public Person Person { get; set; }
        public DateOnly CreatedAt { get; set; }

        public ICollection<RepairOrder> RepairOrders { get; set; } = new List<RepairOrder>();
        public Customer(Person person, DateOnly createdAt)
        {
            Person = person;
            CreatedAt = createdAt;
            
        }
        public Customer() { }
    }
}
