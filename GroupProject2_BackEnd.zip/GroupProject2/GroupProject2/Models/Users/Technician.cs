﻿using GroupProject2.Models.Repairs;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Users
{
    public class Technician
    {
        [Key]
        public int Technician_ID { get; set; }
        public Person Person { get; set; }
        public string Specialty { get; set; }
        public DateOnly HiredDate { get; set; }
        public bool IsActive { get; set; } = true;

        public ICollection<RepairOrder> AssignedOrders { get; set; } = new List<RepairOrder>();
    }
}
