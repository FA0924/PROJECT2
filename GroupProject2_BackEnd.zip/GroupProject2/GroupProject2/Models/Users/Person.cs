﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Users
{
    public class Person
    {

        [Key]
        public int Person_ID { get; set; }
        public string FullName { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }

        public Person(string fullName, string phone, string address)
        {
            FullName = fullName;
            Phone = phone;
            Address = address;
        }
    }
}
