﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Enums
{
    public enum StatusEnum
    {
        Pending,
        Assigned,
        InProgress,
        Completed,
        Cancelled
    }
}
