﻿using GroupProject2.Models.Repairs;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.InvoiceFol
{
    public class Invoice
    {
        [Key]
        public int Invoice_ID { get; set; }

        [ForeignKey(nameof(RepairOrder))]
        public int RepairOrder_ID { get; set; }
        public RepairOrder RepairOrder { get; set; }

        public DateOnly InvoiceDate { get; set; }
        public decimal PartsCost { get; set; }
        public decimal ServiceCost { get; set; }
        public decimal Total { get; set; }
        public string Notes { get; set; }
    }
}
