﻿using GroupProject2.Models.Repairs;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Items
{
    public class ApplianceType
    {
        [Key]
        public int Appliance_ID { get; set; }
        public string Name { get; set; }

        public ICollection<RepairOrder> RepairOrders { get; set; }
    }
}
