﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Repairs
{
    public class RepairPart
    {
        [Key]
        public int RepairPart_ID { get; set; }
        public string PartNumber { get; set; }
        public string Name { get; set; }
        public decimal? DefaultCost { get; set; }
        public int? StockQuantity { get; set; }

        public ICollection<OrderPart> OrderParts { get; set; } = new List<OrderPart>();
    }
}
