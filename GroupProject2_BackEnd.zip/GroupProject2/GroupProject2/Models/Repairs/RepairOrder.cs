﻿using GroupProject2.Models.Items;
using GroupProject2.Models.Users;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GroupProject2.Models.InvoiceFol;

namespace GroupProject2.Models.Repairs
{
    public class RepairOrder
    {
        [Key]
        public int RepairOrder_ID { get; set; }

        [ForeignKey(nameof(Customer))]
        public int Customer_ID { get; set; }
        public Customer Customer { get; set; }

        [ForeignKey(nameof(ApplianceType))]
        public int ApplianceType_ID { get; set; }
        public ApplianceType  ApplianceType { get; set; }

        public string Description { get; set; }
        [Required]
        public DateOnly CreatedAt { get; set; }

        [ForeignKey(nameof(Technician))]
        public int Technician_ID { get; set; }
        public Technician Technician { get; set; }

        [ForeignKey(nameof(OrderStatus))]
        public int OrderStatus_ID { get; set; }
        public OrderStatus OrderStatus { get; set; }

        public DateOnly AppointmentDate { get; set; }

        public decimal ServiceCost { get; set; }
        public decimal PartsCost { get; set; }
        public decimal TotalCost { get; set; }

        public DateOnly? CompletedAt { get; set; }
        public DateOnly? CancelledAt { get; set; }
        public Invoice Invoice { get; set; }

        public ICollection<OrderPart> OrderParts { get; set; } = new List<OrderPart>();
    } 

}
