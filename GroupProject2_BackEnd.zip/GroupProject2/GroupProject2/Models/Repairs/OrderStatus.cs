﻿using GroupProject2.Models.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Repairs
{
    public class OrderStatus
    {
        [Key]
        public int OrderStatus_ID { get; set; }
        [Required]
        public StatusEnum Status { get; set; } = StatusEnum.Pending;

        public ICollection<RepairOrder> RepairOrders { get; set; } = new List<RepairOrder>();
    }
}
