﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Repairs
{
    public class OrderPart
    {
        [Key]
        public int MyProperty { get; set; }

        public int RepairOrder_ID { get; set; }
        public RepairOrder RepairOrder { get; set; }

        public int RepairPart_ID { get; set; }
        public RepairPart RepairPart { get; set; }

        public int Quantity { get; set; }
        public decimal UnitCost { get; set; }
        public decimal Subtotal => Quantity * UnitCost;


    }
}
