﻿using GroupProject2.Models.Services.Customer;
using GroupProject2.Models.Services.InvoiceServ;
using GroupProject2.Models.Services.Orders;
using GroupProject2.Models.Services.Technicians;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Services
{
    public class MainMenu
    {
        public void Show()
        {
            var customerMenu = new CustomerMenu();
            var techMenu = new TechnicianMenu();
            var orderMenu = new RepairOrderMenu();
            var invoiceMenu = new InvoiceService();
            var reportsMenu = new ReportsMenu();

            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\n=== MAIN MENU ===");
                Console.WriteLine("1. Manage Customers");
                Console.WriteLine("2. Manage Technicians");
                Console.WriteLine("3. Manage Repair Orders");
                Console.WriteLine("4. Invoices");
                Console.WriteLine("5. Reports");
                Console.WriteLine("0. Exit");
                Console.Write("Choose: ");
                var c = Console.ReadLine();
                switch (c)
                {
                    case "1": customerMenu.Show(); break;
                    case "2": techMenu.Show(); break;
                    case "3": orderMenu.Show(); break;
                    case "4":
                        Console.WriteLine("\nInvoices:");
                        Console.WriteLine("1. List invoices\n2. View invoice\n0. Back");
                        var invOpt = Console.ReadLine();
                        if (invOpt == "1") invoiceMenu.ListInvoices();
                        else if (invOpt == "2") invoiceMenu.ViewInvoice();
                        break;
                    case "5": reportsMenu.Show(); break;
                    case "0": exit = true; break;
                    default: Console.WriteLine("Invalid option."); break;
                }
            }
            Console.WriteLine("Goodbye.");
        }
    }

}
