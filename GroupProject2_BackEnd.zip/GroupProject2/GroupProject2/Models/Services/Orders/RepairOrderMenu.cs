﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Services.Orders
{
    public class RepairOrderMenu
    {
        private readonly RepairOrderService _svc = new();

        public void Show()
        {
            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\n=== REPAIR ORDERS ===");
                Console.WriteLine("1. Create new order");
                Console.WriteLine("2. Assign technician to order");
                Console.WriteLine("3. Change status");
                Console.WriteLine("4. Complete order (enter costs -> generate invoice)");
                Console.WriteLine("5. Cancel order");
                Console.WriteLine("6. List all orders");
                Console.WriteLine("0. Back");
                Console.Write("Choose: ");
                var c = Console.ReadLine();
                switch (c)
                {
                    case "1": _svc.CreateOrder(); break;
                    case "2": _svc.AssignTechnician(); break;
                    case "3": _svc.ChangeStatus(); break;
                    case "4": _svc.CompleteOrder(); break;
                    case "5": _svc.CancelOrder(); break;
                    case "6": _svc.ListAllOrders(); break;
                    case "0": exit = true; break;
                    default: Console.WriteLine("Invalid option."); break;
                }
            }
        }
    }

}
