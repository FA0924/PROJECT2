﻿using GroupProject2.dbContext;
using GroupProject2.Models.InvoiceFol;
using GroupProject2.Models.Repairs;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

public class RepairOrderService
{
    private readonly ApplicationDbContext _db = new();

    public void CreateOrder()
    {
        Console.WriteLine("\n=== Create Repair Order ===");

        // Choose customer
        Console.Write("Customer ID: ");
        if (!int.TryParse(Console.ReadLine(), out var custId)) { Console.WriteLine("Invalid customer ID."); return; }
        var customer = _db.Customers.Find(custId);
        if (customer == null) { Console.WriteLine("Customer not found."); return; }

        // Choose appliance type
        var types = _db.ApplianceTypes.OrderBy(a => a.Appliance_ID).ToList();
        Console.WriteLine("Appliance Types:");
        foreach (var t in types) Console.WriteLine($"{t.Appliance_ID}. {t.Name}");
        Console.Write("Appliance Type ID: ");
        if (!int.TryParse(Console.ReadLine(), out var atId) || !types.Any(t => t.Appliance_ID == atId))
        { Console.WriteLine("Invalid appliance type."); return; }

        Console.Write("Description of problem: ");
        var desc = Console.ReadLine();

        var order = new RepairOrder
        {
            Customer_ID = custId,
            ApplianceType_ID = atId,
            Description = desc,
            CreatedAt = DateOnly.FromDateTime(DateTime.Now),
            OrderStatus_ID = 1 // Pending
        };

        _db.RepairOrders.Add(order);
        _db.SaveChanges();
        Console.WriteLine($"✔ Order {order.RepairOrder_ID} created (Pending).");
    }

    public void AssignTechnician()
    {
        Console.Write("\nEnter Order ID to assign: ");
        if (!int.TryParse(Console.ReadLine(), out var orderId)) { Console.WriteLine("Invalid ID."); return; }

        var order = _db.RepairOrders.Include(r => r.Customer).FirstOrDefault(r => r.RepairOrder_ID == orderId);
        if (order == null) { Console.WriteLine("Order not found."); return; }

        Console.WriteLine($"Order {order.RepairOrder_ID} for {order.Customer.Person.FullName}: status {order.OrderStatus_ID}");
        var techs = _db.Technicians.ToList();
        Console.WriteLine("Technicians:");
        foreach (var t in techs) Console.WriteLine($"{t.Technician_ID}. {t.Person.FullName} ({t.Specialty})");
        Console.Write("Technician ID (or 0 to cancel): ");
        if (!int.TryParse(Console.ReadLine(), out var techId)) { Console.WriteLine("Invalid ID."); return; }
        if (techId == 0) return;

        var tech = _db.Technicians.Find(techId);
        if (tech == null) { Console.WriteLine("Tech not found."); return; }

        order.Technician_ID = techId;
        order.OrderStatus_ID = 2; // Assigned
        _db.SaveChanges();
        Console.WriteLine($"✔ Assigned to {tech.Person.FullName}");
    }

    public void ChangeStatus()
    {
        Console.Write("\nEnter Order ID to change status: ");
        if (!int.TryParse(Console.ReadLine(), out var id)) { Console.WriteLine("Invalid ID."); return; }

        var order = _db.RepairOrders.Include(r => r.Technician).Include(r => r.Customer).FirstOrDefault(r => r.RepairOrder_ID == id);
        if (order == null) { Console.WriteLine("Order not found."); return; }

        Console.WriteLine($"Current status: {GetStatusName(order.OrderStatus_ID)}");
        var statuses = _db.OrderStatuses.OrderBy(s => s.OrderStatus_ID).ToList();
        Console.WriteLine("Statuses:");
        foreach (var s in statuses) Console.WriteLine($"{s.OrderStatus_ID}. {s.Status}");
        Console.Write("New status ID: ");
        if (!int.TryParse(Console.ReadLine(), out var newStatus) || !statuses.Any(s => s.OrderStatus_ID == newStatus)) { Console.WriteLine("Invalid status."); return; }

        order.OrderStatus_ID = newStatus;

        if (newStatus == 4) // Completed
        {
            CompleteOrderInternal(order.RepairOrder_ID);
            return;
        }
        else if (newStatus == 5) // Cancelled
        {
            order.CancelledAt = DateOnly.FromDateTime(DateTime.Now);
        }

        _db.SaveChanges();
        Console.WriteLine("✔ Status updated.");
    }

    public void CompleteOrder()
    {
        Console.Write("\nEnter Order ID to complete: ");
        if (!int.TryParse(Console.ReadLine(), out var id)) { Console.WriteLine("Invalid ID."); return; }
        var order = _db.RepairOrders.Include(r => r.OrderParts).ThenInclude(op => op.RepairPart).FirstOrDefault(r => r.RepairOrder_ID == id);
        if (order == null) { Console.WriteLine("Order not found."); return; }
        CompleteOrderInternal(order.RepairOrder_ID);
    }

    private void CompleteOrderInternal(int orderId)
    {
        using var tx = _db.Database.BeginTransaction();
        try
        {
            var order = _db.RepairOrders
                .Include(r => r.OrderParts)
                .ThenInclude(op => op.RepairPart)
                .FirstOrDefault(r => r.RepairOrder_ID == orderId);
            if (order == null) { Console.WriteLine("Order not found."); return; }

            Console.WriteLine($"Completing order {order.RepairOrder_ID} (CustomerId={order.Customer_ID})");

            // Enter service cost
            decimal serviceCost = 0;
            Console.Write("Enter service cost (e.g. 50.00): ");
            var svcInput = Console.ReadLine();
            if (!decimal.TryParse(svcInput, out serviceCost)) serviceCost = 0;

            // Optionally add parts used (loop)
            Console.Write("Add parts used now? (y/n): ");
            var addParts = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(addParts) && addParts.Trim().ToLower() == "y")
            {
                AddPartsToOrder(order.RepairOrder_ID);
                // reload order parts
                _db.Entry(order).Collection(o => o.OrderParts).Load();
            }

            // Calculate parts cost
            decimal partsCost = 0;
            if (order.OrderParts != null && order.OrderParts.Any())
            {
                partsCost = order.OrderParts.Sum(op => op.UnitCost * op.Quantity);
            }

            order.ServiceCost = serviceCost;
            order.PartsCost = partsCost;
            order.TotalCost = serviceCost + partsCost;
            order.OrderStatus_ID = 4; // Completed
            order.CompletedAt = DateOnly.FromDateTime(DateTime.Now);

            // Create invoice
            var invoice = new Invoice
            {
                RepairOrder_ID = order.RepairOrder_ID,
                InvoiceDate = DateOnly.FromDateTime(DateTime.Now),
                PartsCost = partsCost,
                ServiceCost = serviceCost,
                Total = serviceCost + partsCost,
                Notes = $"Auto-generated invoice for order {order.RepairOrder_ID}"
            };

            _db.Invoices.Add(invoice);
            _db.SaveChanges();
            tx.Commit();
            Console.WriteLine($"✔ Order completed and invoice {invoice.Invoice_ID} generated. Total: {invoice.Total:C}");
        }
        catch (Exception ex)
        {
            tx.Rollback();
            Console.WriteLine("Error completing order: " + ex.Message);
        }
    }

    public void CancelOrder()
    {
        Console.Write("\nEnter Order ID to cancel: ");
        if (!int.TryParse(Console.ReadLine(), out var id)) { Console.WriteLine("Invalid ID."); return; }
        var order = _db.RepairOrders.Find(id);
        if (order == null) { Console.WriteLine("Order not found."); return; }

        order.OrderStatus_ID = 5; // Cancelled
        order.CancelledAt = DateOnly.FromDateTime(DateTime.Now);
        _db.SaveChanges();
        Console.WriteLine("✔ Order cancelled.");
    }

    public void ListAllOrders()
    {
        Console.WriteLine("\n=== Repair Orders ===");
        var orders = _db.RepairOrders
            .Include(o => o.Customer)
            .Include(o => o.Technician)
            .Include(o => o.ApplianceType)
            .Include(o => o.OrderParts)
            .OrderByDescending(o => o.RepairOrder_ID)
            .ToList();

        if (!orders.Any()) { Console.WriteLine("No orders."); return; }

        Console.WriteLine("ID | Customer | Appliance | Status | Tech | CreatedAt | Total");
        foreach (var o in orders)
        {
            Console.WriteLine($"{o.RepairOrder_ID} | {o.Customer?.Person.FullName} | {o.ApplianceType?.Name} | {GetStatusName(o.OrderStatus_ID)} | {o.Technician?.Person.FullName ?? "-"} | {o.CreatedAt} | {o.TotalCost.ToString()}");
        }
    }

    public void AddPartsToOrder(int orderId)
    {
        var order = _db.RepairOrders.Include(o => o.OrderParts).FirstOrDefault(o => o.RepairOrder_ID == orderId);
        if (order == null) { Console.WriteLine("Order not found."); return; }

        bool done = false;
        while (!done)
        {
            Console.Write("Add existing part or new part? (e = existing / n = new / q = quit): ");
            var c = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(c)) continue;
            c = c.Trim().ToLower();
            if (c == "q") { done = true; break; }

            if (c == "e")
            {
                var parts = _db.RepairParts.ToList();
                if (!parts.Any()) { Console.WriteLine("No parts in catalog. Add new part instead."); continue; }
                Console.WriteLine("Parts:");
                foreach (var p in parts) Console.WriteLine($"{p.RepairPart_ID}. {p.Name} - default {p.DefaultCost:C}");
                Console.Write("Part ID: ");
                if (!int.TryParse(Console.ReadLine(), out var pid) || !parts.Any(p => p.RepairPart_ID == pid)) { Console.WriteLine("Invalid part."); continue; }
                var part = parts.First(p => p.RepairPart_ID == pid);
                Console.Write("Quantity: ");
                if (!int.TryParse(Console.ReadLine(), out var qty) || qty <= 0) { Console.WriteLine("Invalid quantity."); continue; }
                decimal unitCost = part.DefaultCost ?? 0;
                Console.Write($"Unit Cost (enter or press enter to use {unitCost}): ");
                var ucostInput = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(ucostInput) && decimal.TryParse(ucostInput, out var uc)) unitCost = uc;

                var orderPart = new OrderPart { RepairOrder_ID = orderId, RepairPart_ID = pid, Quantity = qty, UnitCost = unitCost };
                _db.OrderParts.Add(orderPart);
                _db.SaveChanges();
                Console.WriteLine("✔ Added.");
            }
            else if (c == "n")
            {
                Console.Write("Part name: ");
                var name = Console.ReadLine();
                Console.Write("Default cost: ");
                decimal defCost = 0; decimal.TryParse(Console.ReadLine(), out defCost);
                var newPart = new RepairPart { Name = name, DefaultCost = defCost };
                _db.RepairParts.Add(newPart);
                _db.SaveChanges();

                Console.Write("Quantity to use: ");
                if (!int.TryParse(Console.ReadLine(), out var qty) || qty <= 0) qty = 1;
                decimal unitCost = defCost;
                Console.Write($"Unit Cost (enter or press enter to use {unitCost}): ");
                var ucostInput = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(ucostInput) && decimal.TryParse(ucostInput, out var uc)) unitCost = uc;

                var orderPart = new OrderPart { RepairOrder_ID = orderId, RepairPart_ID = newPart.RepairPart_ID, Quantity = qty, UnitCost = unitCost };
                _db.OrderParts.Add(orderPart);
                _db.SaveChanges();
                Console.WriteLine("✔ Part created and attached.");
            }
            else
            {
                Console.WriteLine("Unknown option.");
            }
        }
    }

    private string GetStatusName(int statusId)
    {
        var s = _db.OrderStatuses.Find(statusId);
        return statusId.ToString();
    }
}
