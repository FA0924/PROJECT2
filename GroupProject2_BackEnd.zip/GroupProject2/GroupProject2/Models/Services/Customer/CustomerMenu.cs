﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Services.Customer
{
    public class CustomerMenu
    {
        private readonly CustomerService _service;

        public CustomerMenu()
        {
            _service = new CustomerService();
        }

        public void Show()
        {
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("\n=== CUSTOMER MANAGEMENT ===");
                Console.WriteLine("1. Add Customer");
                Console.WriteLine("2. Edit Customer");
                Console.WriteLine("3. Delete Customer");
                Console.WriteLine("4. List All Customers");
                Console.WriteLine("5. Search Customer by ID");
                Console.WriteLine("0. Return to Main Menu");
                Console.Write("Choose: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        _service.AddCustomer();
                        break;

                    case "2":
                        _service.EditCustomer();
                        break;

                    case "3":
                        _service.DeleteCustomer();
                        break;

                    case "4":
                        _service.ListCustomers();
                        break;

                    case "5":
                        _service.GetCustomerById();
                        break;

                    case "0":
                        exit = true;
                        break;

                    default:
                        Console.WriteLine("❌ Invalid option.");
                        break;
                }
            }
        }
    }

}
