﻿using GroupProject2.dbContext;
using GroupProject2.Models.Users;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

public class CustomerService
{
    private readonly ApplicationDbContext _db;

    public CustomerService()
    {
        _db = new ApplicationDbContext();
    }

    // Add new customer
    public void AddCustomer()
    {
        Console.WriteLine("\n=== Add New Customer ===");

        Console.Write("Enter Full Name: ");
        string name = Console.ReadLine();

        Console.Write("Enter Phone: ");
        string phone = Console.ReadLine();

        Console.Write("Enter Address: ");
        string address = Console.ReadLine();
        Person tempPerson = new Person(name,
                       phone,
                       address);

        var customer = new Customer
        (    tempPerson,
             DateOnly.FromDateTime(DateTime.Now)
        );

        _db.Customers.Add(customer);
        _db.SaveChanges();

        Console.WriteLine("✔ Customer added successfully!");
    }

    // Edit existing customer
    public void EditCustomer()
    {
        Console.WriteLine("\n=== Edit Customer ===");

        Console.Write("Enter Customer ID: ");
        if (!int.TryParse(Console.ReadLine(), out int id))
        {
            Console.WriteLine("Invalid ID.");
            return;
        }

        var customer = _db.Customers.Find(id);
        if (customer == null)
        {
            Console.WriteLine("❌ Customer not found.");
            return;
        }

        Console.WriteLine($"Editing customer: {customer.Person.FullName}");

        Console.Write("New Name (leave blank to keep): ");
        string name = Console.ReadLine();
        if (!string.IsNullOrWhiteSpace(name))
            customer.Person.FullName = name;

        Console.Write("New Phone (leave blank to keep): ");
        string phone = Console.ReadLine();
        if (!string.IsNullOrWhiteSpace(phone))
            customer.Person.Phone = phone;

        Console.Write("New Address (leave blank to keep): ");
        string address = Console.ReadLine();
        if (!string.IsNullOrWhiteSpace(address))
            customer.Person.Address = address;

        _db.SaveChanges();
        Console.WriteLine("✔ Customer updated successfully!");
    }

    // Delete customer only if no repair orders exist
    public void DeleteCustomer()
    {
        Console.WriteLine("\n=== Delete Customer ===");

        Console.Write("Enter Customer ID: ");
        if (!int.TryParse(Console.ReadLine(), out int id))
        {
            Console.WriteLine("Invalid ID.");
            return;
        }

        var customer = _db.Customers
            .Include(c => c.RepairOrders)
            .FirstOrDefault(c => c.Customer_ID == id);

        if (customer == null)
        {
            Console.WriteLine("❌ Customer not found.");
            return;
        }

        if (customer.RepairOrders.Any())
        {
            Console.WriteLine("❌ Cannot delete customer — orders exist!");
            return;
        }

        _db.Customers.Remove(customer);
        _db.SaveChanges();

        Console.WriteLine("✔ Customer deleted successfully!");
    }

    // List all customers
    public void ListCustomers()
    {
        Console.WriteLine("\n=== Customer List ===");

        var customers = _db.Customers.ToList();

        if (!customers.Any())
        {
            Console.WriteLine("No customers found.");
            return;
        }

        Console.WriteLine("ID | Name | Phone | Address");

        foreach (var c in customers)
        {
            Console.WriteLine($"{c.Customer_ID} | {c.Person.FullName} | {c.Person.Phone} | {c.Person.Address}");
        }
    }

    // Find a customer by ID
    public Customer GetCustomerById()
    {
        Console.Write("\nEnter Customer ID: ");
        if (!int.TryParse(Console.ReadLine(), out int id))
        {
            Console.WriteLine("Invalid input.");
            return null;
        }

        var customer = _db.Customers.Find(id);

        if (customer == null)
        {
            Console.WriteLine("❌ Customer not found.");
            return null;
        }

        Console.WriteLine($"Customer: {customer.Person.FullName}, Phone: {customer.Person.Phone}");
        return customer;
    }
}
