﻿using GroupProject2.dbContext;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

public class InvoiceService
{
    private readonly ApplicationDbContext _db = new();

    public void ListInvoices()
    {
        Console.WriteLine("\n=== Invoices ===");
        var invoices = _db.Invoices
            .Include(i => i.RepairOrder)
            .ThenInclude(r => r.Customer)
            .OrderByDescending(i => i.Invoice_ID)
            .ToList();

        if (!invoices.Any()) { Console.WriteLine("No invoices."); return; }

        Console.WriteLine("ID | OrderID | Customer | Date | Total");
        foreach (var inv in invoices)
        {
            Console.WriteLine($"{inv.Invoice_ID} | {inv.RepairOrder_ID} | {inv.RepairOrder?.Customer?.Person.FullName} | {inv.InvoiceDate} | {inv.Total:C}");
        }
    }

    public void ViewInvoice()
    {
        Console.Write("\nEnter Invoice ID: ");
        if (!int.TryParse(Console.ReadLine(), out var id)) { Console.WriteLine("Invalid ID."); return; }
        var inv = _db.Invoices
            .Include(i => i.RepairOrder).ThenInclude(r => r.Customer)
            .FirstOrDefault(i => i.Invoice_ID == id);
        if (inv == null) { Console.WriteLine("Not found."); return; }

        Console.WriteLine($"\nInvoice #{inv.Invoice_ID}");
        Console.WriteLine($"Order: {inv.RepairOrder_ID}");
        Console.WriteLine($"Customer: {inv.RepairOrder?.Customer?.Person.FullName}");
        Console.WriteLine($"Date: {inv.InvoiceDate}");
        Console.WriteLine($"Service: {inv.ServiceCost:C}");
        Console.WriteLine($"Parts: {inv.PartsCost:C}");
        Console.WriteLine($"Total: {inv.Total:C}");
        Console.WriteLine($"Notes: {inv.Notes}");
    }
}
