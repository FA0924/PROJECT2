﻿using GroupProject2.dbContext;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

public class ReportsService
{
    private readonly ApplicationDbContext _db = new();

    public void OrdersCountByStatus()
    {
        Console.WriteLine("\n=== Orders Count by Status ===");
        var q = _db.RepairOrders
            .GroupBy(o => o.OrderStatus_ID)
            .Select(g => new { StatusId = g.Key, Count = g.Count() })
            .ToList();

        foreach (var r in q)
        {
            var name = _db.OrderStatuses.Find(r.StatusId)?.Status.ToString() ?? r.StatusId.ToString();
        }
    }

    public void OrdersPerTechnician()
    {
        Console.WriteLine("\n=== Orders Per Technician ===");
        var q = _db.RepairOrders
            .Where(o => o.Technician_ID != null)
            .GroupBy(o => o.Technician_ID)
            .Select(g => new { TechId = g.Key, Count = g.Count() })
            .ToList();

        foreach (var r in q)
        {
            var tech = _db.Technicians.Find(r.TechId);
            Console.WriteLine($"{tech?.Person.FullName ?? "Unknown"}: {r.Count}");
        }
    }

    public void OrdersByDate()
    {
        Console.WriteLine("\n=== Orders By Date Range ===");
        Console.Write("From (yyyy-MM-dd): ");
        if (!DateOnly.TryParse(Console.ReadLine(), out var from)) { Console.WriteLine("Invalid date."); return; }
        Console.Write("To (yyyy-MM-dd): ");
        if (!DateOnly.TryParse(Console.ReadLine(), out var to)) { Console.WriteLine("Invalid date."); return; }

        var orders = _db.RepairOrders
            .Include(o => o.Customer)
            .Where(o => o.CreatedAt >= from && o.CreatedAt <= to)
            .OrderByDescending(o => o.CreatedAt)
            .ToList();

        if (!orders.Any()) { Console.WriteLine("No orders in range."); return; }

        Console.WriteLine("ID | Date | Customer | Status | Total");
        foreach (var o in orders) 
            Console.WriteLine($"{o.RepairOrder_ID} | {o.CreatedAt} | {o.Customer?.Person.FullName} | {o.OrderStatus_ID} | {o.TotalCost}");
    }
}
