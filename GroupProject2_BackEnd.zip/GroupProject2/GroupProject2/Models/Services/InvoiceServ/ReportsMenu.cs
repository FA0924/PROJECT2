﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Services.InvoiceServ
{
    public class ReportsMenu
    {
        private readonly ReportsService _svc = new();

        public void Show()
        {
            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\n=== REPORTS ===");
                Console.WriteLine("1. Orders count by status");
                Console.WriteLine("2. Orders per technician");
                Console.WriteLine("3. Orders by date range");
                Console.WriteLine("0. Back");
                Console.Write("Choose: ");
                var c = Console.ReadLine();
                switch (c)
                {
                    case "1": _svc.OrdersCountByStatus(); break;
                    case "2": _svc.OrdersPerTechnician(); break;
                    case "3": _svc.OrdersByDate(); break;
                    case "0": exit = true; break;
                    default: Console.WriteLine("Invalid option."); break;
                }
            }
        }
    }

}
