﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject2.Models.Services.Technicians
{
    public class TechnicianMenu
    {
        private readonly TechnicianService _svc = new();

        public void Show()
        {
            bool exit = false;
            while (!exit)
            {
                Console.WriteLine("\n=== TECHNICIAN MANAGEMENT ===");
                Console.WriteLine("1. Add technician");
                Console.WriteLine("2. Edit technician");
                Console.WriteLine("3. Delete technician");
                Console.WriteLine("4. List technicians");
                Console.WriteLine("0. Back");
                Console.Write("Choose: ");
                var c = Console.ReadLine();
                switch (c)
                {
                    case "1": _svc.AddTechnician(); break;
                    case "2": _svc.EditTechnician(); break;
                    case "3": _svc.DeleteTechnician(); break;
                    case "4": _svc.ListTechnicians(); break;
                    case "0": exit = true; break;
                    default: Console.WriteLine("Invalid option."); break;
                }
            }
        }
    }

}
