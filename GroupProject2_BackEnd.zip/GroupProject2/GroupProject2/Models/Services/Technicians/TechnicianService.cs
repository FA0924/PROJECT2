﻿using GroupProject2.dbContext;
using GroupProject2.Models.Users;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

public class TechnicianService
{
    private readonly ApplicationDbContext _db = new();

    public void AddTechnician()
    {
        Console.WriteLine("\n=== Add Technician ===");
        Console.Write("Full name: ");
        var name = Console.ReadLine();
        Console.Write("Phone: ");
        var phone = Console.ReadLine();
        Console.Write("Specialty (e.g. Refrigerator): ");
        var specialty = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(phone))
        {
            Console.WriteLine("Name and phone are required.");
            return;
        }
        Person tempPerson = new Person(name, phone,"None");
        var tech = new Technician
        {
            Person = tempPerson,
            Specialty = string.IsNullOrWhiteSpace(specialty) ? null : specialty.Trim(),
            IsActive = true,
            HiredDate = DateOnly.FromDateTime(DateTime.Now)
        };

        _db.Technicians.Add(tech);
        _db.SaveChanges();
        Console.WriteLine("✔ Technician added.");
    }

    public void EditTechnician()
    {
        Console.Write("\nEnter Technician ID to edit: ");
        if (!int.TryParse(Console.ReadLine(), out var id)) { Console.WriteLine("Invalid ID."); return; }

        var tech = _db.Technicians.Find(id);
        if (tech == null) { Console.WriteLine("Technician not found."); return; }

        Console.WriteLine($"Editing {tech.Person.FullName}");
        Console.Write("New name (leave blank to keep): ");
        var name = Console.ReadLine();
        Console.Write("New phone (leave blank to keep): ");
        var phone = Console.ReadLine();
        Console.Write("New specialty (leave blank to keep): ");
        var specialty = Console.ReadLine();

        if (!string.IsNullOrWhiteSpace(name)) tech.Person.FullName = name.Trim();
        if (!string.IsNullOrWhiteSpace(phone)) tech.Person.Phone = phone.Trim();
        if (!string.IsNullOrWhiteSpace(specialty)) tech.Specialty = specialty.Trim();

        _db.SaveChanges();
        Console.WriteLine("✔ Technician updated.");
    }

    public void DeleteTechnician()
    {
        Console.Write("\nEnter Technician ID to delete: ");
        if (!int.TryParse(Console.ReadLine(), out var id)) { Console.WriteLine("Invalid ID."); return; }

        var tech = _db.Technicians.Include(t => t.AssignedOrders).FirstOrDefault(t => t.Technician_ID == id);
        if (tech == null) { Console.WriteLine("Technician not found."); return; }

        // Prevent delete if technician has active orders (Assigned / InProgress)
        var active = tech.AssignedOrders?.Any(o => o.OrderStatus_ID != 4 /*Completed*/ && o.OrderStatus_ID != 5 /*Cancelled*/) ?? false;
        if (active)
        {
            Console.WriteLine("Cannot delete technician: active orders assigned. Reassign or cancel orders first.");
            return;
        }

        _db.Technicians.Remove(tech);
        _db.SaveChanges();
        Console.WriteLine("✔ Technician deleted.");
    }

    public void ListTechnicians()
    {
        Console.WriteLine("\n=== Technicians ===");
        var techs = _db.Technicians.OrderBy(t => t.Technician_ID).ToList();
        if (!techs.Any()) { Console.WriteLine("No technicians."); return; }

        Console.WriteLine("ID | Name | Phone | Specialty | Active");
        foreach (var t in techs)
            Console.WriteLine($"{t.Technician_ID} | {t.Person.FullName} | {t.Person.Phone} | {t.Specialty} | {t.IsActive}");
    }

    public Technician GetTechnicianById(int id)
    {
        return _db.Technicians.Find(id);
    }
}
