﻿using GroupProject2.Models.InvoiceFol;
using GroupProject2.Models.Items;
using GroupProject2.Models.Repairs;
using GroupProject2.Models.Users;
using Microsoft.EntityFrameworkCore;

namespace GroupProject2.dbContext
{
    public class ApplicationDbContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string DbSource = "Data Source=.;" +
                              "Database=GroupProject2;" +
                              "Integrated Security=True;" +
                              "Connect Timeout=30;" +
                              "Encrypt=True;" +
                              "Trust Server Certificate=True;";
            optionsBuilder.UseSqlServer(DbSource);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<RepairOrder>()
     .HasOne(ro => ro.Technician)
     .WithMany()
     .HasForeignKey(ro => ro.Technician_ID)
     .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<RepairOrder>()
                .HasOne(ro => ro.Customer)
                .WithMany()
                .HasForeignKey(ro => ro.Customer_ID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<RepairOrder>()
                .HasOne(ro => ro.ApplianceType)
                .WithMany()
                .HasForeignKey(ro => ro.ApplianceType_ID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<RepairOrder>()
                .HasOne(ro => ro.OrderStatus)
                .WithMany()
                .HasForeignKey(ro => ro.OrderStatus_ID)
                .OnDelete(DeleteBehavior.Restrict);
        }

  
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Technician> Technicians { get; set; }
        public DbSet<ApplianceType> ApplianceTypes { get; set; }
        public DbSet<OrderStatus> OrderStatuses { get; set; }
        public DbSet<RepairOrder> RepairOrders { get; set; }
        public DbSet<RepairPart> RepairParts { get; set; }
        public DbSet<OrderPart> OrderParts { get; set; }
        public DbSet<Invoice> Invoices { get; set; }
    }
}