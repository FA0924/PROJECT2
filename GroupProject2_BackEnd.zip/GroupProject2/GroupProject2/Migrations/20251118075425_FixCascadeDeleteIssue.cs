﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GroupProject2.Migrations
{
    /// <inheritdoc />
    public partial class FixCascadeDeleteIssue : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ApplianceTypes",
                columns: table => new
                {
                    Appliance_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplianceTypes", x => x.Appliance_ID);
                });

            migrationBuilder.CreateTable(
                name: "OrderStatuses",
                columns: table => new
                {
                    OrderStatus_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Status = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderStatuses", x => x.OrderStatus_ID);
                });

            migrationBuilder.CreateTable(
                name: "Person",
                columns: table => new
                {
                    Person_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FullName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Address = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Person", x => x.Person_ID);
                });

            migrationBuilder.CreateTable(
                name: "RepairParts",
                columns: table => new
                {
                    RepairPart_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PartNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DefaultCost = table.Column<decimal>(type: "decimal(18,2)", nullable: true),
                    StockQuantity = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RepairParts", x => x.RepairPart_ID);
                });

            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    Customer_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Person_ID = table.Column<int>(type: "int", nullable: false),
                    CreatedAt = table.Column<DateOnly>(type: "date", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.Customer_ID);
                    table.ForeignKey(
                        name: "FK_Customers_Person_Person_ID",
                        column: x => x.Person_ID,
                        principalTable: "Person",
                        principalColumn: "Person_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Technicians",
                columns: table => new
                {
                    Technician_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Person_ID = table.Column<int>(type: "int", nullable: false),
                    Specialty = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    HiredDate = table.Column<DateOnly>(type: "date", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Technicians", x => x.Technician_ID);
                    table.ForeignKey(
                        name: "FK_Technicians_Person_Person_ID",
                        column: x => x.Person_ID,
                        principalTable: "Person",
                        principalColumn: "Person_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RepairOrders",
                columns: table => new
                {
                    RepairOrder_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Customer_ID = table.Column<int>(type: "int", nullable: false),
                    ApplianceType_ID = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedAt = table.Column<DateOnly>(type: "date", nullable: false),
                    Technician_ID = table.Column<int>(type: "int", nullable: false),
                    OrderStatus_ID = table.Column<int>(type: "int", nullable: false),
                    AppointmentDate = table.Column<DateOnly>(type: "date", nullable: false),
                    ServiceCost = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    PartsCost = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    TotalCost = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    CompletedAt = table.Column<DateOnly>(type: "date", nullable: true),
                    CancelledAt = table.Column<DateOnly>(type: "date", nullable: true),
                    ApplianceTypeAppliance_ID = table.Column<int>(type: "int", nullable: true),
                    Customer_ID1 = table.Column<int>(type: "int", nullable: true),
                    OrderStatus_ID1 = table.Column<int>(type: "int", nullable: true),
                    Technician_ID1 = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RepairOrders", x => x.RepairOrder_ID);
                    table.ForeignKey(
                        name: "FK_RepairOrders_ApplianceTypes_ApplianceTypeAppliance_ID",
                        column: x => x.ApplianceTypeAppliance_ID,
                        principalTable: "ApplianceTypes",
                        principalColumn: "Appliance_ID");
                    table.ForeignKey(
                        name: "FK_RepairOrders_ApplianceTypes_ApplianceType_ID",
                        column: x => x.ApplianceType_ID,
                        principalTable: "ApplianceTypes",
                        principalColumn: "Appliance_ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RepairOrders_Customers_Customer_ID",
                        column: x => x.Customer_ID,
                        principalTable: "Customers",
                        principalColumn: "Customer_ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RepairOrders_Customers_Customer_ID1",
                        column: x => x.Customer_ID1,
                        principalTable: "Customers",
                        principalColumn: "Customer_ID");
                    table.ForeignKey(
                        name: "FK_RepairOrders_OrderStatuses_OrderStatus_ID",
                        column: x => x.OrderStatus_ID,
                        principalTable: "OrderStatuses",
                        principalColumn: "OrderStatus_ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RepairOrders_OrderStatuses_OrderStatus_ID1",
                        column: x => x.OrderStatus_ID1,
                        principalTable: "OrderStatuses",
                        principalColumn: "OrderStatus_ID");
                    table.ForeignKey(
                        name: "FK_RepairOrders_Technicians_Technician_ID",
                        column: x => x.Technician_ID,
                        principalTable: "Technicians",
                        principalColumn: "Technician_ID",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_RepairOrders_Technicians_Technician_ID1",
                        column: x => x.Technician_ID1,
                        principalTable: "Technicians",
                        principalColumn: "Technician_ID");
                });

            migrationBuilder.CreateTable(
                name: "Invoices",
                columns: table => new
                {
                    Invoice_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RepairOrder_ID = table.Column<int>(type: "int", nullable: false),
                    InvoiceDate = table.Column<DateOnly>(type: "date", nullable: false),
                    PartsCost = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ServiceCost = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Total = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    Notes = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Invoices", x => x.Invoice_ID);
                    table.ForeignKey(
                        name: "FK_Invoices_RepairOrders_RepairOrder_ID",
                        column: x => x.RepairOrder_ID,
                        principalTable: "RepairOrders",
                        principalColumn: "RepairOrder_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OrderParts",
                columns: table => new
                {
                    MyProperty = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RepairOrder_ID = table.Column<int>(type: "int", nullable: false),
                    RepairOrder_ID1 = table.Column<int>(type: "int", nullable: false),
                    RepairPart_ID = table.Column<int>(type: "int", nullable: false),
                    RepairPart_ID1 = table.Column<int>(type: "int", nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    UnitCost = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderParts", x => x.MyProperty);
                    table.ForeignKey(
                        name: "FK_OrderParts_RepairOrders_RepairOrder_ID1",
                        column: x => x.RepairOrder_ID1,
                        principalTable: "RepairOrders",
                        principalColumn: "RepairOrder_ID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OrderParts_RepairParts_RepairPart_ID1",
                        column: x => x.RepairPart_ID1,
                        principalTable: "RepairParts",
                        principalColumn: "RepairPart_ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Customers_Person_ID",
                table: "Customers",
                column: "Person_ID");

            migrationBuilder.CreateIndex(
                name: "IX_Invoices_RepairOrder_ID",
                table: "Invoices",
                column: "RepairOrder_ID",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_OrderParts_RepairOrder_ID1",
                table: "OrderParts",
                column: "RepairOrder_ID1");

            migrationBuilder.CreateIndex(
                name: "IX_OrderParts_RepairPart_ID1",
                table: "OrderParts",
                column: "RepairPart_ID1");

            migrationBuilder.CreateIndex(
                name: "IX_RepairOrders_ApplianceType_ID",
                table: "RepairOrders",
                column: "ApplianceType_ID");

            migrationBuilder.CreateIndex(
                name: "IX_RepairOrders_ApplianceTypeAppliance_ID",
                table: "RepairOrders",
                column: "ApplianceTypeAppliance_ID");

            migrationBuilder.CreateIndex(
                name: "IX_RepairOrders_Customer_ID",
                table: "RepairOrders",
                column: "Customer_ID");

            migrationBuilder.CreateIndex(
                name: "IX_RepairOrders_Customer_ID1",
                table: "RepairOrders",
                column: "Customer_ID1");

            migrationBuilder.CreateIndex(
                name: "IX_RepairOrders_OrderStatus_ID",
                table: "RepairOrders",
                column: "OrderStatus_ID");

            migrationBuilder.CreateIndex(
                name: "IX_RepairOrders_OrderStatus_ID1",
                table: "RepairOrders",
                column: "OrderStatus_ID1");

            migrationBuilder.CreateIndex(
                name: "IX_RepairOrders_Technician_ID",
                table: "RepairOrders",
                column: "Technician_ID");

            migrationBuilder.CreateIndex(
                name: "IX_RepairOrders_Technician_ID1",
                table: "RepairOrders",
                column: "Technician_ID1");

            migrationBuilder.CreateIndex(
                name: "IX_Technicians_Person_ID",
                table: "Technicians",
                column: "Person_ID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Invoices");

            migrationBuilder.DropTable(
                name: "OrderParts");

            migrationBuilder.DropTable(
                name: "RepairOrders");

            migrationBuilder.DropTable(
                name: "RepairParts");

            migrationBuilder.DropTable(
                name: "ApplianceTypes");

            migrationBuilder.DropTable(
                name: "Customers");

            migrationBuilder.DropTable(
                name: "OrderStatuses");

            migrationBuilder.DropTable(
                name: "Technicians");

            migrationBuilder.DropTable(
                name: "Person");
        }
    }
}
