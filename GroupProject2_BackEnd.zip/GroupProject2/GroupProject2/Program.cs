﻿using GroupProject2.Models.Services;
using GroupProject2.Models.Services.Customer;

namespace GroupProject2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            var menu = new MainMenu();
            menu.Show();
        }
    }
}
